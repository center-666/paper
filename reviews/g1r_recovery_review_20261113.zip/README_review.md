# G1-R review package

Read reviews/g1_retroactive_recovery/19_manuscript_research_draft.md first, then 18_final_replay_results.md and 17_final_test_preregistration.md.

The draft is not cleared for submission. Full-network shadow and joint write-back are equivalent in MSE under the fixed linear schedule; detection, communication and novelty limitations remain. Final run is complete and must not be repeated or tuned without a new decision.

The package retains repository-relative paths and selected supporting P0 evidence; it does not include licensed original PDFs or the entire repository. SHA256_MANIFEST.json indexes every included file other than this README and the manifest itself.
