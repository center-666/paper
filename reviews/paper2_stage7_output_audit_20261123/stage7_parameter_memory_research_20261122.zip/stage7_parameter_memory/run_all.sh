#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python test_exact_propagation.py
python stage7_replay.py --episodes 12
python verify_replay.py
