"""Exact-Fraction deterministic checks of Stage-7 parameter memory.
No random samples. Covers event trees, signed vector responses, inverse
halfspace transport and exact 2D minimum-norm projection.
"""
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path

A=((F('1.02'),F('.10')),(F(0),F('.97')))
Q=((F('.05'),F(0)),(F(0),F('.05')))
P0=((F('.8'),F(0)),(F(0),F('.8')))
R=F('.2');Z=F(2);B=F('.25')

def mm(X,Y):return tuple(tuple(sum(X[i][k]*Y[k][j] for k in range(len(Y))) for j in range(len(Y[0]))) for i in range(len(X)))
def mt(X):return tuple(zip(*X))
def madd(X,Y):return tuple(tuple(X[i][j]+Y[i][j] for j in range(len(X[0]))) for i in range(len(X)))
def mv(X,x):return tuple(sum(X[i][j]*x[j] for j in range(len(x))) for i in range(len(X)))
def dot(x,y):return sum(a*b for a,b in zip(x,y))
def mat_inv2(X):
 a,b=X[0];c,d=X[1];det=a*d-b*c
 if det==0:return None
 return ((d/det,-b/det),(-c/det,a/det))
def cross(o,a,b):return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])

def fraction_projection(pts):
 pts=sorted(set(pts))
 if not pts:return (F(0),F(0))
 if len(pts)==1:return pts[0]
 low=[];up=[]
 for p in pts:
  while len(low)>=2 and cross(low[-2],low[-1],p)<=0:low.pop()
  low.append(p)
 for p in reversed(pts):
  while len(up)>=2 and cross(up[-2],up[-1],p)<=0:up.pop()
  up.append(p)
 hull=low[:-1]+up[:-1]
 if len(hull)>=3 and all(cross(hull[i],hull[(i+1)%len(hull)],(F(0),F(0)))>=0 for i in range(len(hull))):return (F(0),F(0))
 best=None;val=None
 for i,p in enumerate(hull):
  q=hull[(i+1)%len(hull)];d=tuple(y-x for x,y in zip(p,q));den=dot(d,d)
  r=F(0) if den==0 else min(F(1),max(F(0),-dot(p,d)/den))
  x=tuple(p[j]+r*d[j] for j in range(2));v=dot(x,x)
  if val is None or v<val:best=x;val=v
 return best

def step(P,sent):
 S=P[0][0]+R+(F(0) if sent else F(1)/Z)
 K=(P[0][0]/S,P[1][0]/S)
 T=((F(1)-K[0],F(0)),(-K[1],F(1)))
 Fm=mm(T,A)
 Ppost=mm(T,P)
 Pnext=madd(mm(mm(A,Ppost),mt(A)),Q)
 return Pnext,K,Fm

def exact_tree_test(pattern,start=2,tau=4):
 P=P0;H=[];theta=(F(0),F(0));b=F('0.25');states=[];Fs=[];Ks=[]
 for t,sent in enumerate(pattern):
  P,K,Fm=step(P,sent)
  Fs.append(Fm);Ks.append(K)
  H.append((F(0),F(0)))
  H=[tuple(mv(Fm,h)[j]+(K[j] if sent else 0) for j in range(2)) for h in H]
  theta=tuple(mv(Fm,theta)[j]+(K[j]*b if sent and t>=start else 0) for j in range(2))
  assert theta==tuple(B*x for x in H[start]) if t>=start else theta==(F(0),F(0))
  states.append((tuple(H),theta))
 if dot(theta,theta)==0:return 0,0
 Htau,thetatau=states[tau]
 # Construct a true-compatible, synthetic halfspace; this checks propagation
 # CONDITIONAL on its truth, not statistical validity of a certificate.
 directions=((F(1),F(0)),(F(0),F(1)),(F(1),-F(1)),(-F(1),F(1)),(F(1),F(1)))
 checks=0;nonzero=0
 for d in directions:
  support=dot(d,thetatau)
  if support<=0:continue
  z=support*F(1,3)
  bounds={}
  for k,h in enumerate(Htau):
   a=dot(d,h)
   if a>0 and z/a<=B:bounds[k]=z/a
  assert start in bounds and bounds[start]<=B
  od,oz=d,z
  for t in range(tau,len(pattern)):
   if t>tau:
    Fm=Fs[t];K=Ks[t];inv=mat_inv2(Fm)
    assert inv is not None
    dn=mv(mt(inv),od);zz=oz+min(F(0),dot(dn,K)*B if pattern[t] else F(0))
    od,oz=dn,zz
   Ht,thetat=states[t]
   assert tuple(B*x for x in Ht[start])==thetat
   pts=[]
   for k,l in bounds.items():
    pts.extend((tuple(l*x for x in Ht[k]),tuple(B*x for x in Ht[k])))
   assert len(pts)>0
   # New exact parameter-set endpoints lie in propagated old halfspace.
   for p in pts:assert dot(od,p)>=oz
   c=fraction_projection(pts)
   c_old=tuple((max(F(0),oz)/dot(od,od))*dd for dd in od)
   assert dot(c,c)+F(1,10**12)>=dot(c_old,c_old)
   # Actual truth belongs to one of the retained rays exactly.
   assert dot(thetat,c)*2-dot(c,c)>=dot(c,c)
   checks+=1
   if dot(c,c)>0:nonzero+=1
 return checks,nonzero

def main():
 n=8;paths=0;checks=0;nonzero=0
 for pattern in product((False,True),repeat=n):
  a,b=exact_tree_test(pattern)
  checks+=a;nonzero+=b;paths+=1
 output={'paths':paths,'exact_projection_and_transport_checks':checks,'positive_action_checks':nonzero,
         'arithmetic':'fractions.Fraction','status':'PASS',
         'scope':'conditional-on-valid-halfspace algebra only; synthetic certificates are not likelihood certificates'}
 (Path(__file__).parent/'exact_test_results.json').write_text(json.dumps(output,indent=2))
 print(output)
if __name__=='__main__':main()
