"""Reproduce Stage 7 shadow-replay diagnostics and baseline regression tests."""
import json,zlib
import numpy as np
from pathlib import Path
from scipy.stats import t
HERE=Path(__file__).parent
anchors=json.loads((HERE/'anchors_stage6_strong.json').read_text())['episodes']
rows=[]
for index in range(12):
 for time,level,d0,d1,z in anchors[str(index)]:
  rows.append('|'.join(map(str,(index,time,f'{float(level):.3f}',d0,d1,z))))
checksum=f'{zlib.crc32("\n".join(rows).encode()):08x}'
assert len(rows)==27 and checksum=='2a7a8967',(len(rows),checksum)
asserts=[0.,0.03049736818732875,0.2535480793119236,-0.25778453626643294,
         0.,0.,0.11878216742835049,0.07377616606205452,
         0.057109483539334746,0.018902797696837666,-0.06608580575952226,0.06152753906877551]
replay=json.loads((HERE/'shadow_replay_results.json').read_text())['results']
for k,row in enumerate(replay):
 assert row['episode']==k
 assert abs(row['old']-asserts[k])<1e-8,(k,row['old'],asserts[k])
 assert row['coverage_counterexample_ticks']==0
 assert row['new_worse_guarantee_ticks']==0
 assert row['new_negative_conditional_ticks']==0
assert abs(np.mean([x['monitor'] for x in replay])-324.2811)<1e-3

def estimate(key):
 v=np.array([x[key] for x in replay]);sem=v.std(ddof=1)/np.sqrt(len(v));lo,hi=t.interval(.95,df=11,loc=v.mean(),scale=sem)
 return {'mean':float(v.mean()),'descriptive_t95':[float(lo),float(hi)],'min':float(min(v)),'max':float(max(v))}
stats={k:estimate(k) for k in ['old','new','old_cond','new_cond','old_action_energy','new_action_energy','postprocess_seconds']}
d=np.array([x['new']-x['old'] for x in replay]);sem=d.std(ddof=1)/np.sqrt(12)
stats['paired_new_minus_old']={'mean':float(np.mean(d)),'descriptive_t95':list(map(float,t.interval(.95,df=11,loc=d.mean(),scale=sem)))}
stats['terminal_useful_ge_0025']={policy:{H:int(sum(x['snapshots'][H][policy+'_norm']>=0.025-1e-10 for x in replay)) for H in ('128','256','512')} for policy in ('old','new')}
stats['anchor_checksum']=checksum
stats['copied_certificates']=len(rows)
stats['sample_identity']='same 12 Stage-6 final strong-attack episodes, seeded deterministic replay, no new independent confirmation'
stats['warning']='binary64 version of Stage-7 algorithm; not a formally certified numerical implementation, no re-run of exact likelihood certification'
(HERE/'summary_statistics.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(stats,indent=2))
