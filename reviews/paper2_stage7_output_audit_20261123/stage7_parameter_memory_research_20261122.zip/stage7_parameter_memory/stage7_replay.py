"""Stage 7 shadow replay of Stage 6 frozen strong-attack, successful certificates.

IMPORTANT: This diagnostic uses binary64 propagation and *previously certified*
anchors. It does NOT issue a new confidence certificate. For a proof-producing
implementation, candidate states, endpoint bounds and projection require
validated outward arithmetic (or exact rational propagation).
"""
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from fractions import Fraction
import numpy as np

HERE=Path(__file__).parent
A=np.array([[1.02,.10],[0.,.97]])
Q=.05*np.eye(2);R=.20;Z=2.; P0=.8*np.eye(2)
DELTA=.011628232298833967
BMAX=.25; T0=50; N=562
ANCHORS=json.loads((HERE/'anchors_stage6_strong.json').read_text())['episodes']

def point_to_hull_projection(points):
    """Minimum Euclidean norm point of 2D finite convex hull, binary64 diagnostic."""
    if len(points)==0: return np.zeros(2)
    # Unique, lexicographically sorted, no artificial perturbation
    pts=sorted(set((float(p[0]),float(p[1])) for p in points))
    if len(pts)==1:return np.array(pts[0],float)
    def cross(o,a,b):return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    lower=[]
    for p in pts:
        while len(lower)>=2 and cross(lower[-2],lower[-1],p)<=0:lower.pop()
        lower.append(p)
    upper=[]
    for p in reversed(pts):
        while len(upper)>=2 and cross(upper[-2],upper[-1],p)<=0:upper.pop()
        upper.append(p)
    hull=lower[:-1]+upper[:-1]
    if not hull:return np.zeros(2)
    if len(hull)>=3:
        # vertices ccw; origin must be left of each directed boundary
        if all(cross(hull[i],hull[(i+1)%len(hull)],(0.,0.))>=0
               for i in range(len(hull))):return np.zeros(2)
    best=None;cost=float('inf')
    count=len(hull)
    for i in range(count if count>1 else 1):
        p=np.array(hull[i]);q=np.array(hull[(i+1)%count])
        delta=q-p; norm=float(delta@delta)
        f=0. if norm==0 else float(np.clip(-(p@delta)/norm,0.,1.))
        c=p+f*delta; v=float(c@c)
        if v<cost:best=c;cost=v
    return best

def old_transport(old,F,K,sent):
    if old is None:return None
    d,z=old
    try:d1=np.linalg.solve(F.T,d)
    except np.linalg.LinAlgError:return None
    z1=z+min(0.,float(d1@K)*BMAX) if sent else z
    if z1<=0:return None
    scale=max(abs(d1))
    if scale<1e-15:return None
    return d1/scale,z1/scale

def correction_from_halfspace(old):
    if old is None:return np.zeros(2)
    d,z=old; c=(z/(d@d))*d
    c_norm=np.sum(np.abs(c))
    return c*min(1.,1./c_norm) if c_norm>0 else c

def correction_from_points(points):
    p=point_to_hull_projection(points)
    norm1=np.sum(np.abs(p))
    return p*min(1.,1./norm1) if norm1>0 else p

def load_anchors(index):
    d={}
    for row in ANCHORS[str(index)]:
        t,level,d0,d1,z=row
        d.setdefault(t,[]).append((np.array([float(Fraction(d0)),float(Fraction(d1))]),float(z),level))
    return d

def simulate(index, extra=False):
    rngs=[np.random.default_rng(s) for s in np.random.SeedSequence(
        [202611226602,2,index]).spawn(3)]
    phys,events,phase=rngs
    error=np.linalg.cholesky(P0)@phys.normal(size=2)
    P=P0.copy(); H=np.zeros((0,2),dtype=float)
    theta=np.zeros(2)
    old=None;bounds=None
    anchors=load_anchors(index)
    gains={'old':0.,'new':0.,'old_cond':0.,'new_cond':0.,'old_action_energy':0.,'new_action_energy':0.,'monitor':0.}
    snapshots={}; nonzero_old=nonzero_new=0; active_at_end=0
    old_unsupported=0
    max_raw_new_l1=0.
    max_raw_old_l1=0.
    new_worse_guarantee=0
    new_negative_conditional=0
    start=time.perf_counter()
    for t in range(N):
        v=np.sqrt(R)*phys.normal()
        w=np.linalg.cholesky(Q)@phys.normal(size=2)
        r=0. if t==0 else DELTA*(2*phase.random()-1)
        y=float(error[0]+v)
        sent=bool(events.random()>np.exp(-.5*Z*(y-r)**2))
        b=.25 if sent and t>=T0 else 0.
        Rg=R+(0. if sent else 1./Z)
        K=P[:,0]/(P[0,0]+Rg)
        T=np.eye(2)-np.outer(K,[1.,0.])
        F=T@A
        Ppost=T@P
        P=A@Ppost@A.T+Q
        theta=F@theta+K*b
        posterror=error-K*(y+b if sent else r)
        error=A@posterror+w
        H=np.vstack([H,np.zeros((1,2))])@F.T+(K if sent else 0.)
        old=old_transport(old,F,K,sent)
        # Existing anchor constraint is d.H[k] b >= z at current t.
        if t in anchors:
            for d,z,_ in anchors[t]:
                proposed=d,z
                if np.dot(correction_from_halfspace(proposed),correction_from_halfspace(proposed)) > np.dot(correction_from_halfspace(old),correction_from_halfspace(old)):
                    old=proposed
                if bounds is None:bounds={k:0. for k in range(t+1)}
                # Intersect every existing onset interval with this certified halfspace.
                oldbounds=bounds
                bounds={}
                for k,lb in oldbounds.items():
                    a=float(d@H[k]);
                    if a>0.:
                        newlb=max(lb,z/a)
                        if newlb<=BMAX*(1+1e-10):bounds[k]=min(newlb,BMAX)
                # Given positive certificate, future onsets are definitively excluded.
        if old is not None:
            do,zo=old
            max_raw_old_l1=max(max_raw_old_l1,float(np.sum(np.abs(zo/(do@do)*do))))
        c_old=correction_from_halfspace(old)
        if bounds is None or not bounds:
            c_new=np.zeros(2)
        else:
            ks=np.fromiter(bounds.keys(),dtype=int)
            lo=np.fromiter(bounds.values(),dtype=float)
            pts=np.vstack([H[ks]*lo[:,None],H[ks]*BMAX])
            raw_new=point_to_hull_projection(pts)
            max_raw_new_l1=max(max_raw_new_l1,float(np.sum(np.abs(raw_new))))
            c_new=correction_from_points(pts)
        if t>=T0:
            if c_new@c_new+1e-9<c_old@c_old:new_worse_guarantee+=1
            if 2*(theta@c_new)-c_new@c_new<-1e-9:new_negative_conditional+=1
            gains['monitor']+=float(posterror@posterror)
            gains['old']+=float((posterror@posterror)-(posterror+c_old)@(posterror+c_old))
            gains['new']+=float((posterror@posterror)-(posterror+c_new)@(posterror+c_new))
            gains['old_cond']+=float(2*(theta@c_old)-c_old@c_old)
            gains['new_cond']+=float(2*(theta@c_new)-c_new@c_new)
            gains['old_action_energy']+=float(c_old@c_old)
            gains['new_action_energy']+=float(c_new@c_new)
        if np.linalg.norm(c_old)>=.025:nonzero_old+=1
        if np.linalg.norm(c_new)>=.025:nonzero_new+=1
        if t in (177,305,561):
            snapshots[str(t-T0+1)]={'old_norm':float(np.linalg.norm(c_old)),
                'new_norm':float(np.linalg.norm(c_new)), 'candidate_onsets':len(bounds) if bounds else 0,
                'gain_old':gains['old'], 'gain_new':gains['new'],
                'monitor':gains['monitor']}
        # Offline proof violation diagnostics (these are *not* used by solver)
        if bounds is not None and t>=T0:
            if T0 not in bounds or bounds[T0]>.25+1e-8:
                old_unsupported+=1
            elif np.linalg.norm(theta-(H[T0]*.25))>1e-7:
                raise AssertionError('Response did not reproduce true theta')
            if float(2*(theta@c_new)-c_new@c_new)<-1e-7:
                raise AssertionError('Conditionally unsafe new action')
    return {'episode':index,**gains, 'snapshots':snapshots,
            'old_useful_ticks':nonzero_old,'new_useful_ticks':nonzero_new,
            'coverage_counterexample_ticks':old_unsupported,
            'new_worse_guarantee_ticks':new_worse_guarantee,
            'new_negative_conditional_ticks':new_negative_conditional,
            'max_raw_new_l1':max_raw_new_l1,
            'max_raw_old_l1':max_raw_old_l1,
            'postprocess_seconds':time.perf_counter()-start}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--episodes',type=int,default=12)
    args=ap.parse_args()
    results=[]
    for i in range(args.episodes):
        r=simulate(i);results.append(r)
        print(i,'old gain',round(r['old'],6),'new gain',round(r['new'],6),
              'new guaranteed',round(r['new_action_energy'],6),
              'useful old/new',r['old_useful_ticks'],r['new_useful_ticks'],
              'time',round(r['postprocess_seconds'],3),flush=True)
    p=HERE/'shadow_replay_results.json'
    p.write_text(json.dumps({'note':'Binary64 replay of Stage6 success certificates; not a new statistical certification experiment.','results':results},indent=2))
    print('saved',p)
if __name__=='__main__':main()
